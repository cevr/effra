#!/usr/bin/env python3
"""Prepare a read-only migration from the local Wayfinder snapshot.

This module deliberately has no tracker client.  It turns the checked-in local
issues into deterministic issue, resolution-comment, and graph payloads.  A
later publisher can consume those payloads after reviewing them and resolving
the pending hosted identities.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
from collections import defaultdict
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import urldefrag


SCHEMA_VERSION = 2
INPUT_MANIFEST_SCHEMA_VERSION = 1
REPOSITORY = "cevr/effra"
HISTORICAL_LINK_COMMIT = "779dc58368149452b0fd42b0debb291e3001c8ac"
HISTORICAL_LINK_REVISION = {
    "repository": REPOSITORY,
    "commit": HISTORICAL_LINK_COMMIT,
    "role": "historical-link-target",
}
HOSTED_ROOT = f"https://github.com/{REPOSITORY}"
METADATA_PREFIX = "<!-- "
METADATA_SUFFIX = " -->"
LOCAL_ISSUE_MARKER = "local-wayfinder://"

# These are the four identities already published by the root agent.  They are
# intentionally the only hosted numbers known to the preparer.  Local snapshots
# may be added for a known hosted identity, but no new hosted number or URL is
# inferred here; rerun this read-only preparer after a reviewed mapping update.
KNOWN_HOSTED: dict[str, dict[str, Any]] = {
    "map": {
        "localId": "map",
        "hostedIssueNumber": 1,
        "hostedIssueId": 5764998176,
        "hostedUrl": f"{HOSTED_ROOT}/issues/1",
        "hostedTitle": "Effra language, runtimes, and interoperability map",
        "hostedState": "open",
        "hostedBodySha256": "dd445c84a7cc2be67369ca2b80c5ff95d84562241bcf2262de94e61860393ba1",
        "identityKind": "local-snapshot",
    },
    "state-machines": {
        "localId": "state-machines",
        "hostedIssueNumber": 2,
        "hostedIssueId": 5765048895,
        "hostedUrl": f"{HOSTED_ROOT}/issues/2",
        "hostedTitle": "Checked machines and machine-backed actors",
        "hostedState": "open",
        "hostedBodySha256": "2ec776a2736dff4947f532ad4287aaf3e14d6dd93d5f967cdfa02e958a241fe0",
        "identityKind": "local-snapshot",
    },
    "machine-provider-contract": {
        "localId": "machine-provider-contract",
        "hostedIssueNumber": 3,
        "hostedIssueId": 5765049263,
        "hostedUrl": f"{HOSTED_ROOT}/issues/3",
        "hostedTitle": "Runtime-independent machine plans and userland provider contract",
        "hostedState": "open",
        "hostedBodySha256": "1296408463e472e2077a6d7d4db802b000c63833b7b9c3a9ae0cd226888281db",
        "identityKind": "local-snapshot",
    },
    "machine-provider-conformance": {
        "localId": "machine-provider-conformance",
        "hostedIssueNumber": 4,
        "hostedIssueId": 5765142474,
        "hostedUrl": f"{HOSTED_ROOT}/issues/4",
        "hostedTitle": "Machine execution across independent userland runtime providers",
        "hostedState": "open",
        "hostedBodySha256": "71996a63df66fcdb348222bb9d2552651cc4836cfc71b8a3b4d7f4187350a412",
        "identityKind": "local-snapshot",
    },
}

IMPLEMENTATION_LABEL_PREFIXES = ("implementation:",)
RESEARCH_LABELS = {"research:needed"}


class MigrationError(RuntimeError):
    """A source or mapping shape cannot be transformed safely."""


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_text(value: str) -> str:
    return sha256_bytes(value.encode("utf-8"))


def git_object_type(root: Path, revision: str, relative: str) -> str | None:
    """Return the Git object type at ``revision:path`` when it is present.

    The migration is deliberately offline.  This asks only the repository that
    owns the input snapshot; it never consults a hosted repository or a source
    cache.  A missing path is meaningful evidence for an unresolved link, but
    an unavailable revision or object store is a preparation error: otherwise
    the same nominal input snapshot could produce a different payload merely
    because its historical evidence was unavailable.
    """

    try:
        revision_check = subprocess.run(
            ["git", "-C", str(root), "cat-file", "-e", f"{revision}^{{commit}}"],
            check=False,
            capture_output=True,
            text=True,
        )
        if revision_check.returncode != 0:
            raise MigrationError(f"historical link revision unavailable: {revision}")
        result = subprocess.run(
            ["git", "-C", str(root), "ls-tree", "-z", revision, "--", relative],
            check=False,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise MigrationError(f"historical link object store unavailable: {revision}:{relative}")
    except OSError as error:
        raise MigrationError(f"historical link Git metadata unavailable: {root}") from error

    for entry in result.stdout.split("\0"):
        if not entry:
            continue
        header, _, entry_path = entry.partition("\t")
        if entry_path != relative:
            continue
        fields = header.split()
        if len(fields) >= 2 and fields[1] in {"blob", "tree"}:
            return fields[1]
    return None


def canonical_input_manifest(root: Path, rows: list[dict[str, Any]], mapping: dict[str, Any]) -> dict[str, Any]:
    """Describe every non-generated input used to prepare the payloads.

    The digest covers issue bytes and parsed metadata, the exact preparer and
    the canonical hosted mapping.  Generated payloads are intentionally absent
    so the source digest cannot become circular.
    """

    issue_inputs: list[dict[str, Any]] = []
    for row in rows:
        metadata_text = canonical_json(row["metadata"])
        issue_inputs.append(
            {
                "path": str(row["path"].relative_to(root)),
                "sourceSha256": row["sourceSha256"],
                "metadata": row["metadata"],
                "metadataSha256": sha256_text(metadata_text),
            }
        )
    preparer_path = root / "scripts" / "wayfinder_migration.py"
    if not preparer_path.is_file():
        raise MigrationError(f"missing preparer input: {preparer_path.relative_to(root)}")
    mapping_text = canonical_json(mapping)
    record = {
        "schemaVersion": INPUT_MANIFEST_SCHEMA_VERSION,
        "kind": "wayfinder-input-snapshot",
        "repository": REPOSITORY,
        "historicalLinkRevision": dict(HISTORICAL_LINK_REVISION),
        "inputs": {
            "issues": issue_inputs,
            "preparer": {
                "path": "scripts/wayfinder_migration.py",
                "sha256": sha256_bytes(preparer_path.read_bytes()),
            },
            "hostedMapping": {
                "path": "docs/wayfinder/hosted-identities.json",
                "sha256": sha256_text(mapping_text),
                "localIssueCount": mapping["localIssueCount"],
                "verifiedHostedCount": mapping["verifiedHostedCount"],
                "pendingHostedCount": mapping["pendingHostedCount"],
            },
        },
        "counts": {
            "issueFiles": len(issue_inputs),
            "verifiedHostedIdentities": mapping["verifiedHostedCount"],
            "pendingHostedIdentities": mapping["pendingHostedCount"],
        },
    }
    return {
        "record": record,
        "sha256": sha256_text(canonical_json(record)),
    }


def parse_metadata(path: Path, source: str | None = None) -> dict[str, Any]:
    """Parse the metadata line from already-decoded issue source.

    ``issue_snapshot`` passes the text decoded from its one raw-byte read.  A
    path-only call remains useful to small callers, but it also decodes bytes
    explicitly instead of using text-mode newline translation.
    """

    if source is None:
        try:
            source = path.read_bytes().decode("utf-8")
        except UnicodeDecodeError as error:
            raise MigrationError(f"{path}: issue source is not valid UTF-8") from error
    lines = source.splitlines(keepends=True)
    if not lines or not lines[0].startswith(METADATA_PREFIX) or not lines[0].rstrip().endswith(METADATA_SUFFIX):
        raise MigrationError(f"{path}: first line is not Wayfinder metadata")
    try:
        metadata = json.loads(lines[0].strip()[len(METADATA_PREFIX) : -len(METADATA_SUFFIX)])
    except json.JSONDecodeError as error:
        raise MigrationError(f"{path}: invalid metadata JSON: {error}") from error
    expected = {"id", "title", "status", "labels", "parent", "assignee", "blocked_by"}
    if set(metadata) != expected:
        raise MigrationError(f"{path}: metadata keys differ from {sorted(expected)}")
    if not isinstance(metadata["id"], str) or not metadata["id"]:
        raise MigrationError(f"{path}: issue id must be a non-empty string")
    if not isinstance(metadata["title"], str) or not metadata["title"]:
        raise MigrationError(f"{path}: issue title must be a non-empty string")
    if metadata["status"] not in {"open", "closed"}:
        raise MigrationError(f"{path}: invalid status {metadata['status']!r}")
    if not isinstance(metadata["labels"], list) or not all(isinstance(label, str) for label in metadata["labels"]):
        raise MigrationError(f"{path}: labels must be a string list")
    if metadata["parent"] is not None and not isinstance(metadata["parent"], str):
        raise MigrationError(f"{path}: parent must be null or a local issue ID")
    if not isinstance(metadata["blocked_by"], list) or not all(isinstance(ref, str) for ref in metadata["blocked_by"]):
        raise MigrationError(f"{path}: blocked_by must be a string list")
    return metadata


def issue_snapshot(root: Path) -> list[dict[str, Any]]:
    directory = root / "docs" / "wayfinder" / "issues"
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for path in sorted(directory.glob("*.md")):
        try:
            raw_source = path.read_bytes()
            decoded_source = raw_source.decode("utf-8")
        except UnicodeDecodeError as error:
            raise MigrationError(f"{path}: issue source is not valid UTF-8") from error
        # Preserve raw_source for identity while making the semantic body
        # newline-stable from that same read.  A second filesystem read here
        # could bind a changed body to the original byte hash.
        source = decoded_source.replace("\r\n", "\n").replace("\r", "\n")
        metadata = parse_metadata(path, source)
        local_id = metadata["id"]
        if local_id in seen:
            raise MigrationError(f"duplicate local issue identity: {local_id}")
        seen.add(local_id)
        rows.append(
            {
                "metadata": metadata,
                "path": path,
                "source": source,
                "sourceSha256": sha256_bytes(raw_source),
            }
        )
    if not rows:
        raise MigrationError(f"no local issues found under {directory}")
    by_id = {row["metadata"]["id"]: row for row in rows}
    for row in rows:
        metadata = row["metadata"]
        refs = list(metadata["blocked_by"])
        if metadata["parent"] is not None:
            refs.append(metadata["parent"])
        for ref in refs:
            if ref not in by_id:
                raise MigrationError(f"{metadata['id']}: unknown local reference {ref}")
    visit_state: dict[str, int] = {}

    def visit(local_id: str) -> None:
        state = visit_state.get(local_id, 0)
        if state == 1:
            raise MigrationError(f"local dependency cycle includes {local_id}")
        if state == 2:
            return
        visit_state[local_id] = 1
        for ref in by_id[local_id]["metadata"]["blocked_by"]:
            visit(ref)
        visit_state[local_id] = 2

    for local_id in sorted(by_id):
        visit(local_id)
    return rows


def bootstrap_mapping(rows: list[dict[str, Any]]) -> dict[str, Any]:
    identities: list[dict[str, Any]] = []
    local_ids = {row["metadata"]["id"] for row in rows}
    for row in rows:
        metadata = row["metadata"]
        local_id = metadata["id"]
        known = KNOWN_HOSTED.get(local_id)
        if known is None:
            identities.append(
                {
                    "localId": local_id,
                    "localTitle": metadata["title"],
                    "hostedStatus": "pending",
                    "hostedIssueNumber": None,
                    "hostedIssueId": None,
                    "hostedUrl": None,
                    "hostedTitle": None,
                    "hostedState": None,
                    "hostedBodySha256": None,
                    "identityKind": "local-snapshot",
                }
            )
        else:
            identity = dict(known)
            identity["localTitle"] = metadata["title"]
            identity["hostedStatus"] = "verified"
            identities.append(identity)
    for local_id, known in sorted(KNOWN_HOSTED.items()):
        if local_id in local_ids:
            continue
        if known["identityKind"] != "hosted-only":
            raise MigrationError(f"known hosted identity {local_id} has no local snapshot")
        identity = dict(known)
        identity["localTitle"] = None
        identity["hostedStatus"] = "verified"
        identities.append(identity)
    identities.sort(key=lambda item: (item["localId"] is None, item["localId"] or item["hostedUrl"]))
    return {
        "schemaVersion": SCHEMA_VERSION,
        "repository": REPOSITORY,
        "historicalLinkRevision": dict(HISTORICAL_LINK_REVISION),
        "mapLocalId": "map",
        "migrationStatus": "pending-first-hosted-publication",
        "localIssueCount": len(rows),
        "verifiedHostedCount": sum(identity["hostedStatus"] == "verified" for identity in identities),
        "pendingHostedCount": sum(identity["hostedStatus"] == "pending" for identity in identities),
        "identities": identities,
    }


def load_mapping(path: Path, rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not path.exists():
        return bootstrap_mapping(rows)
    try:
        mapping = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise MigrationError(f"{path}: invalid mapping JSON: {error}") from error
    if not isinstance(mapping, dict) or mapping.get("schemaVersion") != SCHEMA_VERSION:
        raise MigrationError(f"{path}: unsupported identity mapping schema")
    if mapping.get("repository") != REPOSITORY or mapping.get("historicalLinkRevision") != HISTORICAL_LINK_REVISION:
        raise MigrationError(f"{path}: repository or historical link revision differs from the accepted snapshot")
    identities = mapping.get("identities")
    if not isinstance(identities, list):
        raise MigrationError(f"{path}: identities must be a list")
    local_ids = {row["metadata"]["id"] for row in rows}
    mapped_local_ids = {identity.get("localId") for identity in identities if identity.get("localId") is not None}
    if mapped_local_ids != local_ids:
        # A previously generated mapping may contain a verified hosted-only
        # identity that now has a checked-in local snapshot. Promote only when
        # the hosted issue number and every immutable hosted field match the
        # known identity; never infer a new number or URL from local ordering.
        known_by_number = {
            known["hostedIssueNumber"]: (local_id, known)
            for local_id, known in KNOWN_HOSTED.items()
            if known["identityKind"] == "local-snapshot" and local_id in local_ids
        }
        promoted: list[dict[str, Any]] = []
        for identity in identities:
            if identity.get("localId") is None and identity.get("hostedStatus") == "verified":
                candidate = known_by_number.get(identity.get("hostedIssueNumber"))
                if candidate is not None:
                    local_id, known = candidate
                    immutable_fields = (
                        "hostedIssueNumber",
                        "hostedIssueId",
                        "hostedUrl",
                        "hostedTitle",
                        "hostedState",
                        "hostedBodySha256",
                    )
                    if all(identity.get(field) == known.get(field) for field in immutable_fields):
                        promoted_identity = dict(identity)
                        promoted_identity["localId"] = local_id
                        promoted_identity["localTitle"] = next(
                            row["metadata"]["title"] for row in rows if row["metadata"]["id"] == local_id
                        )
                        promoted_identity["identityKind"] = "local-snapshot"
                        promoted.append(promoted_identity)
                        continue
            promoted.append(identity)
        identities = promoted
        mapped_local_ids = {identity.get("localId") for identity in identities if identity.get("localId") is not None}
    if mapped_local_ids - local_ids:
        extra = sorted(mapped_local_ids - local_ids)
        raise MigrationError(f"{path}: local identity set differs (extra={extra})")
    for row in rows:
        local_id = row["metadata"]["id"]
        if local_id in mapped_local_ids:
            continue
        known = KNOWN_HOSTED.get(local_id)
        if known is not None:
            identity = dict(known)
            identity["localTitle"] = row["metadata"]["title"]
            identity["hostedStatus"] = "verified"
        else:
            identity = {
                "localId": local_id,
                "localTitle": row["metadata"]["title"],
                "hostedStatus": "pending",
                "hostedIssueNumber": None,
                "hostedIssueId": None,
                "hostedUrl": None,
                "hostedTitle": None,
                "hostedState": None,
                "hostedBodySha256": None,
                "identityKind": "local-snapshot",
            }
        identities.append(identity)
        mapped_local_ids.add(local_id)
    if mapped_local_ids != local_ids:
        missing = sorted(local_ids - mapped_local_ids)
        extra = sorted(mapped_local_ids - local_ids)
        raise MigrationError(f"{path}: local identity set differs (missing={missing}, extra={extra})")
    mapping["identities"] = identities
    mapping["localIssueCount"] = len(rows)
    mapping["verifiedHostedCount"] = sum(identity.get("hostedStatus") == "verified" for identity in identities)
    mapping["pendingHostedCount"] = sum(identity.get("hostedStatus") == "pending" for identity in identities)
    identities.sort(key=lambda item: (item.get("localId") is None, item.get("localId") or item.get("hostedUrl")))
    seen_hosted: set[int] = set()
    seen_local: set[str] = set()
    for identity in identities:
        local_id = identity.get("localId")
        if local_id is not None:
            if local_id in seen_local:
                raise MigrationError(f"{path}: duplicate local identity {local_id}")
            seen_local.add(local_id)
        number = identity.get("hostedIssueNumber")
        hosted_status = identity.get("hostedStatus")
        if hosted_status not in {"pending", "verified"}:
            raise MigrationError(f"{path}: invalid hostedStatus for {local_id}: {hosted_status!r}")
        if hosted_status == "pending":
            if any(identity.get(field) is not None for field in ("hostedIssueNumber", "hostedIssueId", "hostedUrl", "hostedTitle", "hostedState", "hostedBodySha256")):
                raise MigrationError(f"{path}: pending identity {local_id} contains hosted data")
        else:
            if not isinstance(number, int) or number <= 0:
                raise MigrationError(f"{path}: verified identity {local_id} lacks a hosted issue number")
            if number in seen_hosted:
                raise MigrationError(f"{path}: duplicate hosted issue number {number}")
            seen_hosted.add(number)
            if not isinstance(identity.get("hostedIssueId"), int) or not isinstance(identity.get("hostedUrl"), str):
                raise MigrationError(f"{path}: verified identity {local_id} lacks exact hosted identity")
    return mapping


def identity_index(mapping: dict[str, Any]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for identity in mapping["identities"]:
        local_id = identity.get("localId")
        if local_id is not None:
            result[local_id] = identity
    return result


def hosted_url(mapping: dict[str, Any], local_id: str, anchor: str = "") -> str | None:
    identity = identity_index(mapping).get(local_id)
    if identity is None or identity.get("hostedStatus") != "verified":
        return None
    return f"{identity['hostedUrl']}{anchor}"


def issue_id_for_path(root: Path, path: Path) -> str | None:
    issue_root = root / "docs" / "wayfinder" / "issues"
    try:
        relative = path.relative_to(issue_root)
    except ValueError:
        return None
    if relative.suffix != ".md" or len(relative.parts) != 1:
        return None
    return relative.stem


def lexical_relative_path(root: Path, source_path: Path, path_text: str) -> PurePosixPath | None:
    """Resolve a Markdown relative path without consulting the current tree.

    Historical link identity is the lexical source location plus the path in
    the Markdown document.  Normalizing ``..`` is necessary for containment,
    but following symlinks or checking the current filesystem would make the
    result depend on an unpublished working tree rather than the selected Git
    revision.
    """

    try:
        source_relative = source_path.relative_to(root)
    except ValueError as error:
        raise MigrationError(f"source path is outside the input snapshot: {source_path}") from error
    components = list(PurePosixPath(source_relative.as_posix()).parent.parts)
    components.extend(PurePosixPath(path_text).parts)
    normalized: list[str] = []
    for component in components:
        if component in {"", "."}:
            continue
        if component == "..":
            if not normalized:
                return None
            normalized.pop()
            continue
        normalized.append(component)
    return PurePosixPath(*normalized)


LINK_PATTERN = re.compile(r"(?P<open>\]\()(?P<target>[^)\s]+)(?P<close>\))")


def rewrite_links(
    markdown: str,
    *,
    root: Path,
    source_path: Path,
    mapping: dict[str, Any],
    unresolved: list[dict[str, str]],
    historical_revision: str = HISTORICAL_LINK_COMMIT,
) -> str:
    def replace(match: re.Match[str]) -> str:
        target = match.group("target")
        if target.startswith(("http://", "https://", "mailto:", "#", "/")):
            return match.group(0)
        path_text, anchor = urldefrag(target)
        target_relative = lexical_relative_path(root, source_path, path_text)
        if target_relative is None:
            unresolved.append(
                {
                    "kind": "path",
                    "source": target,
                    "status": "unresolved",
                    "reason": "outside-input-snapshot",
                }
            )
            return f"](local-reference:{target})"
        target_path = root.joinpath(*target_relative.parts)
        local_id = issue_id_for_path(root, target_path)
        if local_id is not None:
            resolved = hosted_url(mapping, local_id, f"#{anchor}" if anchor else "")
            if resolved is not None:
                return f"]({resolved})"
            unresolved.append({"kind": "issue", "localId": local_id, "source": target})
            unresolved_target = f"{LOCAL_ISSUE_MARKER}{local_id}"
            if anchor:
                unresolved_target += f"#{anchor}"
            return f"]({unresolved_target})"
        relative = target_relative
        kind = git_object_type(root, historical_revision, relative.as_posix())
        if kind is None:
            unresolved.append(
                {
                    "kind": "path",
                    "source": target,
                    "path": relative.as_posix(),
                    "status": "unresolved",
                    "reason": "absent-at-historical-link-revision",
                    "historicalLinkCommit": historical_revision,
                }
            )
            return f"](local-reference:{relative.as_posix()})"
        rewritten = f"{HOSTED_ROOT}/{kind}/{historical_revision}/{relative.as_posix()}"
        if anchor:
            rewritten += f"#{anchor}"
        return f"]({rewritten})"

    return LINK_PATTERN.sub(replace, markdown)


def strip_metadata_and_title(source: str, title: str) -> str:
    lines = source.splitlines(keepends=True)
    if not lines:
        raise MigrationError("empty issue source")
    body = lines[1:]
    if body and body[0].startswith("# "):
        expected_heading = f"# {title}"
        if body[0].rstrip("\n") != expected_heading:
            raise MigrationError(f"title heading differs from metadata: {body[0].rstrip()!r} != {expected_heading!r}")
        body = body[1:]
    return "".join(body).strip() + "\n"


HEADING_PATTERN = re.compile(r"^## .+$")


def sections(markdown: str) -> list[tuple[str, str]]:
    lines = markdown.splitlines(keepends=True)
    starts = [index for index, line in enumerate(lines) if HEADING_PATTERN.match(line.rstrip("\n"))]
    result: list[tuple[str, str]] = []
    if not starts:
        return [("", markdown)] if markdown.strip() else []
    if starts[0] > 0 and "".join(lines[: starts[0]]).strip():
        result.append(("", "".join(lines[: starts[0]])))
    for position, start in enumerate(starts):
        end = starts[position + 1] if position + 1 < len(starts) else len(lines)
        heading = lines[start].strip()[3:].strip()
        result.append((heading, "".join(lines[start:end])))
    return result


def first_paragraph_split(markdown: str) -> tuple[str, str | None]:
    """Split an unheaded closed answer after its first paragraph."""
    lines = markdown.splitlines(keepends=True)
    for index in range(1, len(lines)):
        if not lines[index - 1].strip() and lines[index].strip():
            body = "".join(lines[:index]).strip() + "\n"
            remainder = "".join(lines[index:]).strip()
            return body, (remainder + "\n" if remainder else None)
    return markdown.strip() + "\n", None


def question_paragraph_split(markdown: str) -> tuple[str, str | None]:
    """Keep the first paragraph of a question section in the issue body."""
    lines = markdown.splitlines(keepends=True)
    content_start = 1 if lines and lines[0].lstrip().startswith("## ") else 0
    while content_start < len(lines) and not lines[content_start].strip():
        content_start += 1
    for index in range(content_start + 1, len(lines)):
        if not lines[index - 1].strip() and lines[index].strip():
            body = "".join(lines[:index]).strip() + "\n"
            remainder = "".join(lines[index:]).strip()
            return body, (remainder + "\n" if remainder else None)
    return markdown.strip() + "\n", None


def split_issue_content(row: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
    metadata = row["metadata"]
    local_id = metadata["id"]
    content = strip_metadata_and_title(row["source"], metadata["title"])
    if metadata["status"] == "open":
        return content, []

    parsed = sections(content)
    question = next((body for heading, body in parsed if heading.lower() == "question"), None)
    if question is not None:
        question_index = next(index for index, (heading, _) in enumerate(parsed) if heading.lower() == "question")
        body = question
        comments = [
            {"ordinal": ordinal, "body": section_body, "sourceHeading": heading, "syntheticHeading": False}
            for ordinal, (heading, section_body) in enumerate(parsed[question_index + 1 :], 1)
            if section_body.strip()
        ]
        # A few early closed records put the resolution paragraph directly in
        # the Question section.  Keep its actual question paragraph in the
        # issue body and move the remainder into a named resolution comment.
        if len(parsed) == question_index + 1:
            body, remainder = question_paragraph_split(question)
            if remainder is not None:
                comments = [
                    {
                        "ordinal": 1,
                        "body": f"## Resolution\n\n{remainder}",
                        "sourceHeading": "Resolution",
                        "syntheticHeading": True,
                    }
                ]
        return body.strip() + "\n", comments

    resolution_index = next(
        (
            index
            for index, (heading, _) in enumerate(parsed)
            if heading.lower() == "resolution" or "resolution" in heading.lower()
        ),
        None,
    )
    if resolution_index is None:
        body, remainder = first_paragraph_split(content)
        comments = []
        if remainder is not None:
            comments.append(
                {
                    "ordinal": 1,
                    "body": f"## Resolution\n\n{remainder}",
                    "sourceHeading": "Resolution",
                    "syntheticHeading": True,
                }
            )
        return body, comments
    body = "".join(section_body for _, section_body in parsed[:resolution_index]).strip() + "\n"
    comments = [
        {"ordinal": ordinal, "body": section_body, "sourceHeading": heading, "syntheticHeading": False}
        for ordinal, (heading, section_body) in enumerate(parsed[resolution_index:], 1)
        if section_body.strip()
    ]
    return body, comments


def migrated_labels(labels: list[str]) -> list[str]:
    result = list(dict.fromkeys(labels))
    if any(label.startswith(IMPLEMENTATION_LABEL_PREFIXES) for label in labels) and "wayfinder:task" not in result:
        result.append("wayfinder:task")
    if any(label in RESEARCH_LABELS for label in labels) and "wayfinder:research" not in result:
        result.append("wayfinder:research")
    return result


def payload_header(input_snapshot: dict[str, Any]) -> dict[str, Any]:
    return {
        "schemaVersion": SCHEMA_VERSION,
        "repository": REPOSITORY,
        "historicalLinkRevision": dict(HISTORICAL_LINK_REVISION),
        "inputSnapshot": {
            "path": "docs/wayfinder/migration/input-manifest.json",
            "sha256": input_snapshot["sha256"],
        },
    }


def build_payloads(
    root: Path,
    rows: list[dict[str, Any]],
    mapping: dict[str, Any],
    input_snapshot: dict[str, Any],
) -> dict[str, Any]:
    identity_by_local = identity_index(mapping)
    issues: list[dict[str, Any]] = []
    comments: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    unresolved_refs: list[dict[str, str]] = []
    for row in rows:
        metadata = row["metadata"]
        local_id = metadata["id"]
        body, raw_comments = split_issue_content(row)
        body_unresolved: list[dict[str, str]] = []
        rewritten_body = rewrite_links(
            body,
            root=root,
            source_path=row["path"],
            mapping=mapping,
            unresolved=body_unresolved,
            historical_revision=HISTORICAL_LINK_COMMIT,
        )
        rewritten_comments: list[dict[str, Any]] = []
        for comment in raw_comments:
            comment_unresolved: list[dict[str, str]] = []
            rewritten = rewrite_links(
                comment["body"],
                root=root,
                source_path=row["path"],
                mapping=mapping,
                unresolved=comment_unresolved,
                historical_revision=HISTORICAL_LINK_COMMIT,
            )
            rewritten_comments.append({**comment, "body": rewritten, "unresolvedReferences": comment_unresolved})
            unresolved_refs.extend({"sourceLocalId": local_id, **ref} for ref in comment_unresolved)
        unresolved_refs.extend({"sourceLocalId": local_id, **ref} for ref in body_unresolved)
        identity = identity_by_local[local_id]
        is_verified = identity["hostedStatus"] == "verified"
        issues.append(
            {
                "localId": local_id,
                "title": metadata["title"],
                "operation": "preserve-existing" if is_verified else "create",
                "publishable": not is_verified,
                "desiredState": metadata["status"],
                "labels": migrated_labels(metadata["labels"]),
                "originalLabels": metadata["labels"],
                "historicalAssignee": metadata["assignee"],
                "hostedAssignees": [],
                "parentLocalId": metadata["parent"],
                "blockedByLocalIds": metadata["blocked_by"],
                "body": rewritten_body,
                "sourcePath": str(row["path"].relative_to(root)),
                "sourceSha256": row["sourceSha256"],
                "unresolvedReferences": body_unresolved,
                "hostedIdentity": {
                    "status": identity["hostedStatus"],
                    "number": identity.get("hostedIssueNumber"),
                    "issueId": identity.get("hostedIssueId"),
                    "url": identity.get("hostedUrl"),
                },
            }
        )
        comments.append(
            {
                "localId": local_id,
                "title": metadata["title"],
                "desiredState": metadata["status"],
                "comments": rewritten_comments,
                "sourceSha256": row["sourceSha256"],
            }
        )
        if metadata["parent"] is not None:
            edges.append(edge_payload("parent", local_id, metadata["parent"], identity_by_local, mapping))
        for blocker in metadata["blocked_by"]:
            edges.append(edge_payload("blocked-by", local_id, blocker, identity_by_local, mapping))
    if len(issues) != len(rows) or len(comments) != len(rows):
        raise MigrationError("issue and comment payload counts do not match the local snapshot")
    if len({issue["localId"] for issue in issues}) != len(issues):
        raise MigrationError("duplicate issue payload identity")
    if len({comment["localId"] for comment in comments}) != len(comments):
        raise MigrationError("duplicate comment payload identity")
    unresolved_refs = sorted(
        {json.dumps(reference, ensure_ascii=False, sort_keys=True): reference for reference in unresolved_refs}.values(),
        key=lambda reference: json.dumps(reference, ensure_ascii=False, sort_keys=True),
    )
    return {
        "issues": {**payload_header(input_snapshot), "items": issues},
        "resolutionComments": {**payload_header(input_snapshot), "items": comments},
        "edges": {
            **payload_header(input_snapshot),
            "items": sorted(edges, key=lambda edge: (edge["kind"], edge["childLocalId"], edge["parentLocalId"])),
        },
        "unresolvedReferences": {**payload_header(input_snapshot), "items": unresolved_refs},
    }


def edge_payload(
    kind: str,
    child_local_id: str,
    parent_local_id: str,
    identities: dict[str, dict[str, Any]],
    mapping: dict[str, Any],
) -> dict[str, Any]:
    child = identities[child_local_id]
    parent = identities[parent_local_id]
    child_verified = child["hostedStatus"] == "verified"
    parent_verified = parent["hostedStatus"] == "verified"
    publishable = child_verified and parent_verified
    return {
        "kind": kind,
        "childLocalId": child_local_id,
        "parentLocalId": parent_local_id,
        "childHostedIssueNumber": child.get("hostedIssueNumber"),
        "parentHostedIssueNumber": parent.get("hostedIssueNumber"),
        "childHostedUrl": child.get("hostedUrl"),
        "parentHostedUrl": parent.get("hostedUrl"),
        "publishable": publishable,
        "status": "ready-to-publish" if publishable else "pending-hosted-identities",
        "relationshipStatus": "unverified",
        "relationshipReceipt": None,
        "pendingLocalIds": sorted(
            local_id
            for local_id, identity in ((child_local_id, child), (parent_local_id, parent))
            if identity["hostedStatus"] != "verified"
        ),
    }


def expected_files(
    root: Path,
    mapping: dict[str, Any],
    input_snapshot: dict[str, Any],
    payloads: dict[str, Any],
) -> dict[Path, str]:
    output = root / "docs" / "wayfinder" / "migration"
    identity_text = canonical_json(mapping)
    issues_text = canonical_json(payloads["issues"])
    comments_text = canonical_json(payloads["resolutionComments"])
    edges_text = canonical_json(payloads["edges"])
    unresolved_text = canonical_json(payloads["unresolvedReferences"])
    input_manifest = {
        **input_snapshot["record"],
        "canonicalContentSha256": input_snapshot["sha256"],
    }
    manifest = {
        "schemaVersion": SCHEMA_VERSION,
        "repository": REPOSITORY,
        "historicalLinkRevision": dict(HISTORICAL_LINK_REVISION),
        "mappingPath": "docs/wayfinder/hosted-identities.json",
        "inputSnapshot": {
            "path": "docs/wayfinder/migration/input-manifest.json",
            "sha256": input_snapshot["sha256"],
        },
        "payloads": {
            "issues": {"path": "docs/wayfinder/migration/issues.json", "sha256": sha256_text(issues_text)},
            "resolutionComments": {
                "path": "docs/wayfinder/migration/resolution-comments.json",
                "sha256": sha256_text(comments_text),
            },
            "edges": {"path": "docs/wayfinder/migration/edges.json", "sha256": sha256_text(edges_text)},
            "unresolvedReferences": {
                "path": "docs/wayfinder/migration/unresolved-references.json",
                "sha256": sha256_text(unresolved_text),
            },
        },
        "counts": {
            "localIssues": len(payloads["issues"]["items"]),
            "closedIssues": sum(item["desiredState"] == "closed" for item in payloads["issues"]["items"]),
            "resolutionComments": sum(len(item["comments"]) for item in payloads["resolutionComments"]["items"]),
            "graphEdges": len(payloads["edges"]["items"]),
            "publishableIssues": sum(item["publishable"] for item in payloads["issues"]["items"]),
            "pendingEdges": sum(not item["publishable"] for item in payloads["edges"]["items"]),
            "unresolvedReferences": len(payloads["unresolvedReferences"]["items"]),
        },
    }
    return {
        root / "docs" / "wayfinder" / "hosted-identities.json": identity_text,
        output / "input-manifest.json": canonical_json(input_manifest),
        output / "issues.json": issues_text,
        output / "resolution-comments.json": comments_text,
        output / "edges.json": edges_text,
        output / "unresolved-references.json": unresolved_text,
        output / "manifest.json": canonical_json(manifest),
    }


def validate_payloads(
    root: Path,
    rows: list[dict[str, Any]],
    mapping: dict[str, Any],
    input_snapshot: dict[str, Any],
    payloads: dict[str, Any],
) -> None:
    if mapping["localIssueCount"] != len(rows):
        raise MigrationError("identity mapping localIssueCount is stale")
    identity_by_local = identity_index(mapping)
    if set(identity_by_local) != {row["metadata"]["id"] for row in rows}:
        raise MigrationError("identity mapping does not cover exactly the local snapshot")
    for payload_name in ("issues", "resolutionComments", "edges", "unresolvedReferences"):
        payload = payloads[payload_name]
        if payload.get("schemaVersion") != SCHEMA_VERSION:
            raise MigrationError(f"{payload_name}: unsupported payload schema")
        if payload.get("repository") != REPOSITORY:
            raise MigrationError(f"{payload_name}: repository differs from the accepted snapshot")
        if payload.get("historicalLinkRevision") != HISTORICAL_LINK_REVISION:
            raise MigrationError(f"{payload_name}: historical link revision differs from the accepted snapshot")
        if payload.get("inputSnapshot", {}).get("sha256") != input_snapshot["sha256"]:
            raise MigrationError(f"{payload_name}: input snapshot hash differs from the source inputs")
    issues = payloads["issues"]["items"]
    comments = payloads["resolutionComments"]["items"]
    edges = payloads["edges"]["items"]
    if len(issues) != len(rows) or len(comments) != len(rows):
        raise MigrationError("payload issue/comment set does not cover all local IDs")
    if {item["localId"] for item in issues} != set(identity_by_local):
        raise MigrationError("issue payload identities differ from the local set")
    by_local = {item["localId"]: item for item in issues}
    comment_by_local = {item["localId"]: item for item in comments}
    if any(item["localId"] not in comment_by_local for item in issues):
        raise MigrationError("missing resolution-comment payload")
    for row in rows:
        metadata = row["metadata"]
        payload = by_local[metadata["id"]]
        if payload["desiredState"] != metadata["status"] or payload["parentLocalId"] != metadata["parent"]:
            raise MigrationError(f"{metadata['id']}: status/parent changed during migration")
        if payload["blockedByLocalIds"] != metadata["blocked_by"]:
            raise MigrationError(f"{metadata['id']}: blocker list changed during migration")
        if metadata["status"] == "closed" and not comment_by_local[metadata["id"]]["comments"]:
            raise MigrationError(f"{metadata['id']}: closed issue lost its resolution record")
        if metadata["status"] == "open" and comment_by_local[metadata["id"]]["comments"]:
            raise MigrationError(f"{metadata['id']}: open issue unexpectedly gained resolution comments")
    local_ids = set(identity_by_local)
    for edge in edges:
        if edge["childLocalId"] not in local_ids or edge["parentLocalId"] not in local_ids:
            raise MigrationError(f"dangling local graph edge: {edge}")
        if edge["publishable"] and (edge["childHostedUrl"] is None or edge["parentHostedUrl"] is None):
            raise MigrationError(f"publishable edge has no hosted endpoints: {edge}")
        if not edge["publishable"] and not edge["pendingLocalIds"]:
            raise MigrationError(f"pending edge has no pending identity: {edge}")
        if edge["status"] not in {"ready-to-publish", "pending-hosted-identities"}:
            raise MigrationError(f"edge status is not endpoint readiness: {edge}")
        if edge.get("relationshipStatus") != "unverified" or edge.get("relationshipReceipt") is not None:
            raise MigrationError(f"edge claims relationship evidence without a retained receipt: {edge}")
    if any("](" + "docs/" in item["body"] for item in issues):
        raise MigrationError("issue payload contains an unreconciled repository-relative link")
    unresolved_items = payloads["unresolvedReferences"]["items"]
    unresolved_by_local = defaultdict(list)
    for reference in unresolved_items:
        unresolved_by_local[reference["sourceLocalId"]].append(reference)

    def validate_links(local_id: str, markdown: str, declared: list[dict[str, Any]]) -> None:
        declared_keys = {json.dumps(reference, ensure_ascii=False, sort_keys=True) for reference in declared}
        available_keys = {
            json.dumps(
                {key: value for key, value in reference.items() if key != "sourceLocalId"},
                ensure_ascii=False,
                sort_keys=True,
            )
            for reference in unresolved_by_local[local_id]
        }
        for match in LINK_PATTERN.finditer(markdown):
            target = match.group("target")
            if target.startswith(f"{HOSTED_ROOT}/blob/") or target.startswith(f"{HOSTED_ROOT}/tree/"):
                path_text, _ = urldefrag(target)
                kind, revision, relative = path_text[len(f"{HOSTED_ROOT}/") :].split("/", 2)
                if revision != HISTORICAL_LINK_COMMIT:
                    raise MigrationError(f"{local_id}: repository link is bound to an unaccepted revision: {target}")
                if git_object_type(root, revision, relative) != kind:
                    raise MigrationError(f"{local_id}: repository link target is absent or has the wrong type: {target}")
            elif target.startswith("local-reference:") or target.startswith(LOCAL_ISSUE_MARKER):
                kind = "issue" if target.startswith(LOCAL_ISSUE_MARKER) else "path"
                if kind == "issue":
                    local_reference = target[len(LOCAL_ISSUE_MARKER) :].split("#", 1)[0]
                    expected = {"kind": "issue", "localId": local_reference}
                else:
                    expected = {"kind": "path", "path": target[len("local-reference:") :]}
                if not any(
                    all(reference.get(key) == value for key, value in expected.items())
                    for reference in unresolved_by_local[local_id]
                ):
                    raise MigrationError(f"{local_id}: unresolved link has no retained source record: {target}")
        if not declared_keys.issubset(available_keys):
            raise MigrationError(f"{local_id}: declared unresolved reference is absent from the global record")

    for item in issues:
        validate_links(item["localId"], item["body"], item["unresolvedReferences"])
    for item in payloads["resolutionComments"]["items"]:
        for comment in item["comments"]:
            validate_links(item["localId"], comment["body"], comment["unresolvedReferences"])
    expected_comments = sum(len(item["comments"]) for item in comments)
    if expected_comments < sum(item["desiredState"] == "closed" for item in issues):
        raise MigrationError("not every closed issue has a separate resolution comment")


def run(root: Path, mapping_path: Path, write: bool, check: bool) -> int:
    rows = issue_snapshot(root)
    mapping = load_mapping(mapping_path, rows)
    input_snapshot = canonical_input_manifest(root, rows, mapping)
    payloads = build_payloads(root, rows, mapping, input_snapshot)
    validate_payloads(root, rows, mapping, input_snapshot, payloads)
    files = expected_files(root, mapping, input_snapshot, payloads)
    stale: list[str] = []
    for path, expected in files.items():
        if not path.exists() or path.read_text(encoding="utf-8") != expected:
            stale.append(str(path.relative_to(root)))
    if check:
        if stale:
            print("stale migration artifacts:")
            for path in stale:
                print(f"- {path}")
            return 1
        print(
            f"wayfinder migration: {len(rows)} local issues, "
            f"{sum(item['desiredState'] == 'closed' for item in payloads['issues']['items'])} closed, "
            f"{sum(len(item['comments']) for item in payloads['resolutionComments']['items'])} resolution comments, "
            f"{len(payloads['edges']['items'])} graph edges"
        )
        return 0
    if not write:
        print(canonical_json(payloads["issues"]), end="")
        return 0
    for path, expected in files.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding="utf-8")
    print(
        f"wrote {len(files)} read-only migration artifacts for {len(rows)} local issues "
        f"({sum(item['desiredState'] == 'closed' for item in payloads['issues']['items'])} closed)"
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--mapping", type=Path, default=None)
    parser.add_argument("--write", action="store_true", help="write deterministic mapping and payload artifacts")
    parser.add_argument("--check", action="store_true", help="check deterministic artifacts without writing")
    args = parser.parse_args(argv)
    if args.write and args.check:
        parser.error("--write and --check are mutually exclusive")
    root = args.root.resolve()
    mapping_path = (args.mapping or root / "docs" / "wayfinder" / "hosted-identities.json").resolve()
    try:
        return run(root, mapping_path, args.write, args.check)
    except MigrationError as error:
        print(f"wayfinder migration: error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
