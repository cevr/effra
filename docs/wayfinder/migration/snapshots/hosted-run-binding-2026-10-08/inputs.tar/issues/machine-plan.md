<!-- {"id": "machine-plan", "title": "Canonical machine plans and transition checks", "status": "open", "labels": ["implementation:task"], "parent": "state-machines", "assignee": null, "blocked_by": ["native-interfaces", "generic-data", "effect-recovery", "actor-protocol"]} -->
# Canonical machine plans and transition checks

Implement the declaration-only machine binding over ordinary step/entry/completion functions, bounded product-match coverage, explicit Step outcomes and source-bound possible graphs. Go always re-enters; Stay retains an entry and requires the same tag. Two unrelated programs and every negative acceptance in the [spec](../../specs/state-machines.md) must pass. Unsupported advanced constructs diagnose; no whole-program reachability inference or opaque callbacks.

Owner clarification: step/completion functions may be pure or effectful. Preserve their declared failures/services through ordinary helper calls, charge requirements at spawn and expose terminal failures to waiting observations. Graph construction never executes a decision or claims current enabledness.
